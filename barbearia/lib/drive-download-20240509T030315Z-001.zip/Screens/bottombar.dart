import 'package:flutter/material.dart';

class Bottombar extends StatelessWidget {
  const Bottombar({super.key});

  @override
  Widget build(BuildContext context) {
    return
          BottomNavigationBar(
            backgroundColor: const Color(0xff312F2F),
            items: const <BottomNavigationBarItem>[
              BottomNavigationBarItem(
                icon: Icon(Icons.home ),
                label: 'HOME'
              ),
              BottomNavigationBarItem(
                  icon: Icon(Icons.list),
                  label: 'LISTA'
              )
            ],

            selectedItemColor: Colors.amber[800],

          );
  }
}
