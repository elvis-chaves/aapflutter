import 'dart:js_interop';

import 'package:barbearia/Screens/bottombar.dart';
import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';



class Menu extends StatelessWidget {
  const Menu({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor:const Color(0xff05253B),
      appBar: AppBar(
         backgroundColor: Colors.white70,
          title: const Text('Home', style: TextStyle(color: Color(0xffffffff)),),
      ),
       body: Center(
         child: Container(
          height:460.0,
          margin: const EdgeInsets.all(16),
          decoration: BoxDecoration(color: Colors.white70, borderRadius: BorderRadius.circular(16),
          ),
          child: Center(child:Image.asset ("assets/Rectangle3.png",),

          ),


               ),
       ),
      bottomNavigationBar: Bottombar(),

    );

   
  }

}
